import React from 'react';

const QuickMath: React.FC = () => {
  return (
    <div className="quick-math-container">
      <h2>Quick Math</h2>
      <p>This game is under construction.</p>
    </div>
  );
};

export default QuickMath;