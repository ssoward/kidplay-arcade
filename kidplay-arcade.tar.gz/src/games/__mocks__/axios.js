const axios = {
  post: jest.fn(),
};
export default axios;
